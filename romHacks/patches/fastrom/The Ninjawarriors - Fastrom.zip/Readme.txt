This is for the USA version of "The Ninjawarriors"

Thanks to DJ_Draco for capturing the playthrough!

SPECIAL THANKS TO ALL MY PATREONS

EXTRA SPECIAL THANKS TO TOP PATREONS:

ANONYMOUS
RC_Meatpuppet
SAM M.