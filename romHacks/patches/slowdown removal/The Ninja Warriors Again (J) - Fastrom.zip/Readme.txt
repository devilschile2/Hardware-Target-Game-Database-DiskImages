This is for the Japan version of "The Ninja Warriors Again"

SPECIAL THANKS TO ALL MY PATREONS

EXTRA SPECIAL THANKS TO TOP PATREONS:

ANONYMOUS
RC_Meatpuppet
SAM M.